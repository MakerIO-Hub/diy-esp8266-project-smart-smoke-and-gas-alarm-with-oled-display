#include <ESP8266WiFi.h>
#include <time.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <LittleFS.h>

// Wi-Fi Bilgilerin
const char* ssid     = "xxxssidxxx";
const char* password = "xxxpasswordxxx";

// Ekran boyutları (128x64)
Adafruit_SSD1306 display(128, 64, &Wire, -1);

// Pin Tanımlamaları
const int mq2Pin = A0;      
const int buzzerPin = D7;   
const int ledPin = D5;      
const int buttonPin = D6;   

// Hassasiyet Eşik Değeri
const int esikDegeri = 400; 

// NTP Sunucu Ayarları
const char* ntpServer = "pool.ntp.org";
const long  gmtOffset_sec = 3 * 3600; 
const int   daylightOffset_sec = 0;   

unsigned long sonAktiviteZamani = 0; 
unsigned long susturmaBaslangicZamani = 0;
bool alarmSusturuldu = false;

// --- EKRAN MODLARI ---
// 0: Ekran Koruyucu (Sarı-Mavi Saat/Tarih), 1: Başlangıç Sayfası (Saat+Tarih+Hava Kalitesi), 2: Grafik, 3: Loglar
int ekranModu = 1; 

bool alarmTetiklendi = false; 

// Interrupt Değişkenleri
volatile bool butonBasildi = false;
unsigned long sonInterruptZamani = 0;

ICACHE_RAM_ATTR void butonKesmesi() {
  unsigned long simdikiMilis = millis();
  if (simdikiMilis - sonInterruptZamani > 250) {
    butonBasildi = true;
    sonInterruptZamani = simdikiMilis;
  }
}

int filtreliGazOku() {
  long toplam = 0;
  for(int i = 0; i < 10; i++) {
    toplam += analogRead(mq2Pin);
    delay(10); 
  }
  return toplam / 10; 
}

void kaliciLogEkle(struct tm* timeinfo) {
  char formatliZaman[25];
  strftime(formatliZaman, sizeof(formatliZaman), "%H:%M - %d-%m-%Y", timeinfo);
  
  File logDosyasi = LittleFS.open("/alarm_log.txt", "a");
  if (logDosyasi) {
    logDosyasi.println(formatliZaman);
    logDosyasi.close();
  }
}

void kaliciLoglariEkranaBas() {
  if (!LittleFS.exists("/alarm_log.txt")) {
    display.setCursor(15, 35);
    display.print("KAYIT BULUNAMADI");
    return;
  }

  File logDosyasi = LittleFS.open("/alarm_log.txt", "r");
  if (!logDosyasi) return;

  String sonKayitlar[3];
  int toplamSatir = 0;

  while (logDosyasi.available()) {
    String satir = logDosyasi.readStringUntil('\n');
    satir.trim();
    if (satir.length() > 0) {
      sonKayitlar[toplamSatir % 3] = satir;
      toplamSatir++;
    }
  }
  logDosyasi.close();

  if (toplamSatir == 0) {
    display.setCursor(15, 35);
    display.print("KAYIT BULUNAMADI");
    return;
  }

  int yPozisyonu = 18;
  int gosterilecekAdet = toplamSatir > 3 ? 3 : toplamSatir;
  
  for (int i = 0; i < gosterilecekAdet; i++) {
    int indeks = (toplamSatir - 1 - i) % 3;
    display.setCursor(3, yPozisyonu);
    display.print(sonKayitlar[indeks]);
    yPozisyonu += 15;
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(buzzerPin, OUTPUT);
  pinMode(ledPin, OUTPUT);     
  
  pinMode(buttonPin, INPUT_PULLUP); 
  attachInterrupt(digitalPinToInterrupt(buttonPin), butonKesmesi, FALLING);

  digitalWrite(ledPin, LOW);   

  Wire.begin();
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { for(;;); }
  
  display.setTextWrap(false);
  display.clearDisplay();
  display.setTextColor(WHITE);
  
  display.setTextSize(1);
  display.setCursor(15, 25);
  display.print("Wi-Fi Baglaniyor...");
  display.display();
  
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  
  if (!LittleFS.begin()) {
    LittleFS.format();
    LittleFS.begin();
  }

  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
  struct tm timeinfo;
  while (!getLocalTime(&timeinfo)) { delay(500); }

  display.clearDisplay();
  display.setCursor(25, 28);
  display.print("SISTEM HAZIR!");
  display.display();
  delay(2000); 
  
  sonAktiviteZamani = millis(); 
}

void loop() {
  int gazDegeri = filtreliGazOku(); 
  unsigned long simdikiMilis = millis();

  struct tm timeinfo;
  bool saatOkundu = getLocalTime(&timeinfo);

  if (butonBasildi) {
    butonBasildi = false; 
    sonAktiviteZamani = simdikiMilis;
    
    if (gazDegeri > esikDegeri) {
      alarmSusturuldu = true;
      susturmaBaslangicZamani = simdikiMilis;
    } else {
      if (ekranModu == 0) {
        ekranModu = 1;
      } else {
        ekranModu++;
        if (ekranModu > 3) ekranModu = 1; 
      }
    }
  }

  if (ekranModu != 0 && gazDegeri <= esikDegeri && (simdikiMilis - sonAktiviteZamani >= 15000)) {
    ekranModu = 0;
  }

  if (alarmSusturuldu && (simdikiMilis - susturmaBaslangicZamani >= 60000)) {
    alarmSusturuldu = false; 
  }

  display.clearDisplay(); 
  
  if (gazDegeri > esikDegeri) {
    // --- ALARM DURUMU ---
    display.invertDisplay(true); 
    
    if(!alarmTetiklendi && saatOkundu) {
      kaliciLogEkle(&timeinfo);
      alarmTetiklendi = true; 
    }
    
    display.setTextSize(2);
    display.setCursor(15, 10);
    if(alarmSusturuldu) {
      display.print("MUTED..."); 
    } else {
      display.print("TEHLIKE!");
    }
    
    display.setTextSize(1);
    display.setCursor(10, 45);
    display.print("DUMAN/GAZ: ");
    display.print(gazDegeri);
    display.display();

    if (!alarmSusturuldu) {
      digitalWrite(ledPin, HIGH); 
      tone(buzzerPin, 5000); 
      delay(150);
      
      digitalWrite(ledPin, LOW);  
      tone(buzzerPin, 1600);  
      delay(150);
    } else {
      noTone(buzzerPin);
      digitalWrite(ledPin, LOW);
      delay(300); 
    }
    
    sonAktiviteZamani = simdikiMilis; 
    
  } else {
    // --- NORMAL DURUM ---
    display.invertDisplay(false); 
    noTone(buzzerPin);            
    digitalWrite(ledPin, LOW);  
    alarmTetiklendi = false; 
    alarmSusturuldu = false; 

    if (ekranModu == 0 && saatOkundu) {
      // --- MOD 0: EKRAN KORUYUCU (Sarı-Mavi Saat/Tarih) ---
      char saatBuf[9];   
      char tarihBuf[12]; 
      strftime(saatBuf, sizeof(saatBuf), "%H:%M:%S", &timeinfo);
      strftime(tarihBuf, sizeof(tarihBuf), "%d.%m.%Y", &timeinfo);

      display.setTextSize(2);
      display.setCursor(16, 12); // Saati, donanımsal sarı-mavi kesişimine getirmeye çalıştık
      display.print(saatBuf);

      display.setTextSize(1); 
      display.setCursor(34, 38); // Tarihi daha aşağıya (mavi bölgeye) aldık
      display.print(tarihBuf);
    } 
    else if (ekranModu == 1 && saatOkundu) {
      // --- MOD 1: BAŞLANGIÇ SAYFASI (Sarı-Mavi Etki) ---
      char saatBuf[9];   
      char tarihBuf[12]; 
      strftime(saatBuf, sizeof(saatBuf), "%H:%M:%S", &timeinfo);
      strftime(tarihBuf, sizeof(tarihBuf), "%d.%m.%Y", &timeinfo);

      display.setTextSize(2);
      display.setCursor(16, 5); // Saati en tepeye (sarı bölgeye) aldık
      display.print(saatBuf);

      display.setTextSize(1); 
      display.setCursor(34, 30); // Tarihi ve hava kalitesini mavi bölgeye aldık
      display.print(tarihBuf);

      String havaYazisi = "Hava Kalitesi: " + String(gazDegeri);
      int xEksen = (128 - (havaYazisi.length() * 6)) / 2; 
      display.setCursor(xEksen, 50);
      display.print(havaYazisi);
    }
    else if (ekranModu == 2) {
      display.setTextSize(1); 
      display.setCursor(0, 2);
      display.print("HAVA: TEMIZ");
      
      display.drawLine(0, 14, 128, 14, WHITE); 
      display.setCursor(10, 25);
      display.print("Anlik Deger: ");
      display.print(gazDegeri);

      display.drawLine(0, 48, 128, 48, WHITE); 
      display.drawRect(10, 52, 108, 10, WHITE); 
      
      int barGenislik = map(gazDegeri, 0, esikDegeri, 0, 104); 
      barGenislik = constrain(barGenislik, 0, 104); 
      display.fillRect(12, 54, barGenislik, 6, WHITE); 
    } 
    else if (ekranModu == 3) {
      display.setTextSize(1);
      display.setCursor(0, 2);
      display.print("--- ALARM GEGMISI ---");
      display.drawLine(0, 13, 128, 13, WHITE);
      
      kaliciLoglariEkranaBas();
    }
    
    display.display();
    delay(300); 
  }
}